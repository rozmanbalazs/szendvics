from tkinter import *
from tkinter import ttk
import webbrowser

bg_colors = ""
fg_colors = ""

with open("bg.txt", "r") as file:
    bg_colors = file.read()

with open("fg.txt", "r") as file:
    fg_colors = file.read()

root = Tk()
root.geometry("300x400")
root.title("szendvics számoló")
root.resizable(False,False)
root.config(bg=bg_colors)
root.iconbitmap("favicon.ico")

szendo_pic = PhotoImage(file="hambi.png")
szendo_pic1 = PhotoImage(file="szalamis.png")
szendo_pic2 = PhotoImage(file="rantott.png")

calc = 0
calc_pez = 0
rantott = 0
szalami = 0
hamburger = 0

theme_selector_bg = StringVar()
theme_selector_fg = StringVar()
szendo = IntVar()

def logic():
    global calc, calc_pez, rantott, szalami, hamburger

    szendvicsek = szendo.get()

    if szendvicsek == 0:
        szamlalo.config(text="Válassz szendvicset")

    elif szendvicsek == 1:
        calc += 1
        calc_pez += 400
        rantott += 1
        valasz_final = "rántotthús - {}".format(rantott)
        valaszto.config(text=valasz_final)
        szamlalo.config(text=calc)
        finalpez = "{} HUF".format(calc_pez)
        szamlalo_pez.config(text=finalpez)

    elif szendvicsek == 2:
        calc += 1
        calc_pez += 250
        szalami += 1
        valasz_final = "szalámis - {}".format(szalami)
        valaszto1.config(text=valasz_final)
        szamlalo.config(text=calc)
        finalpez = "{} HUF".format(calc_pez)
        szamlalo_pez.config(text=finalpez)    
    
    elif szendvicsek == 3:
        calc += 1
        calc_pez += 300
        hamburger += 1
        valasz_final = "hamburgir - {}".format(hamburger)
        valaszto2.config(text=valasz_final)
        szamlalo.config(text=calc)
        finalpez = "{} HUF".format(calc_pez)
        szamlalo_pez.config(text=finalpez)    


def colorapply():
    selected_color_bg = theme_selector_bg.get()
    selected_color_fg = theme_selector_fg.get()

    with open("bg.txt", "w") as file:
        file.write(selected_color_bg)

    with open("fg.txt", "w") as file:
        file.write(selected_color_fg)


szamlalo = Label(root, text="0", font=("roboto",25), fg=fg_colors, bg=bg_colors)
szamlalo.pack(pady=50)

gomb_hozzaad = Button(root, command=logic, text="+1 Szendvics", font=("roboto",20), fg="black", bg="lime", activebackground="green")
gomb_hozzaad.pack(pady=20)

valaszto = Radiobutton(root, text="rántotthúsos", variable=szendo, value=1, fg=fg_colors, bg=bg_colors, activebackground="red")
valaszto.pack()

valaszto1 = Radiobutton(root, text="szalámis", variable=szendo, value=2, fg=fg_colors, bg=bg_colors, activebackground="red")
valaszto1.pack()

valaszto2 = Radiobutton(root, text="hamburgir", variable=szendo, value=3, fg=fg_colors, bg=bg_colors, activebackground="red")
valaszto2.pack()

szamlalo_pez = Label(root, text="0 HUF", font=("roboto",15), fg=fg_colors, bg=bg_colors)
szamlalo_pez.pack(pady=10)

Label(root, text="bg:").place(x=10, y=380, anchor=CENTER)

themeselector_bg = ttk.Combobox(root, textvariable=theme_selector_bg, width=7, state="readonly")
themeselector_bg["values"] = ["black", "red", "yellow", "brown", "cyan", "green"]
themeselector_bg.current(0)
themeselector_bg.place(x=55, y=380, anchor=CENTER)

Label(root, text="fg:").place(x=106, y=380, anchor=CENTER)

themeselector_fg = ttk.Combobox(root, textvariable=theme_selector_fg, width=7, state="readonly")
themeselector_fg["values"] = ["black", "red", "yellow", "brown", "cyan", "green"]
themeselector_fg.current(1)
themeselector_fg.place(x=150, y=380, anchor=CENTER)

themeapply = Button(root, text="Apply", font=("roboto", 8), bg="lightgreen", command=colorapply)
themeapply.place(x=220, y=380, anchor=CENTER)

def open1():
	webbrowser.open("https://www.felegyhazipekseg.com/termekek/rantott-husos-szendvics")

def open2():
	webbrowser.open("https://m.kaloriabazis.hu/recept/teliszalamis_szendvics_kcal/91047_0")
	
def open3():
	webbrowser.open("https://mennyikaloria.hu/kaloria-adatbazis/etelek-italok/5150_Hamburger")
	
Button(root, image=szendo_pic, bg=bg_colors, border=0, activebackground=bg_colors, command=open3).place(x=230, y=303, anchor=CENTER)
Button(root, image=szendo_pic1, bg=bg_colors, border=0, activebackground=bg_colors, command=open2).place(x=230, y=278, anchor=CENTER)
Button(root, image=szendo_pic2, bg=bg_colors, border=0, activebackground=bg_colors, command=open1).place(x=230, y=254, anchor=CENTER)

root.mainloop()